RedMargin icon pack

Contents:
- PNGs named redmargin_{N}x{N}@{scale}x.png
  where N ∈ {16, 32, 64, 128, 256, 512, 1024} and scale ∈ {1, 2, 3}.
- RedMargin.iconset (standard macOS iconset: 16/32/128/256/512 plus @2x variants)

Build .icns on macOS:
iconutil -c icns RedMargin.iconset
